<?php

/**
 * CreateBookingsTable Migration
 *
 * @class CreateBookingsTable
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instaveritas Pvt. Ltd. All rights reserved.
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bookings', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id');
            $table->integer('studio_id');
            $table->date('booking_date');
            $table->unsignedTinyInteger('slot_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bookings');
    }
}
