<?php

/**
 * CreateStudiosTable Migration
 *
 * @class CreateStudiosTable
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instaveritas Pvt. Ltd. All rights reserved.
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudiosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studios', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('email')->unique();
            $table->string('contact');
            $table->string('address')->nullable();
            $table->time("open");
            $table->time("close");
            $table->unsignedTinyInteger('is_active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('studios');
    }
}
