<?php

/**
 * @package Resources/Lang/En/Messages
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instavertias Pvt. Ltd. All rights reserved.
 */

return [
    'internal_server_error' => 'Internal server error',
    'studio_created_successfully' => 'Studio created successfully',
    'studio_deleted_successfully' => 'Studio deleted successfully',
    'studio_updated_successfully' => 'Studio updated successfully',
    'slot_not_available' => 'The selected slot is not available.',
];
