<?php
/**
 * All user-defined constants placed here
 *
 * @package config
 *
 * @file constants.php
 *
 * @author Azim Khan <azim@surmountsoft.in>
 *
 * @copyright 2021 Instavertia Pvt. Ltd. All rights reserved.
 */

return [
    'SLOTS' => [
        1 => 'Time: 10:00AM - 11:00AM',
        2 => 'Time: 11:00AM - 12:00AM',
        3 => 'Time: 12:00AM - 01:00PM',
        4 => 'Time: 01:00PM - 02:00PM',
        5 => 'Time: 02:00PM - 03:00PM',
        6 => 'Time: 03:00PM - 04:00PM',
        7 => 'Time: 04:00PM - 05:00PM',
        8 => 'Time: 05:00PM - 06:00PM',
        9 => 'Time: 06:00PM - 07:00PM',
        10 => 'Time: 07:00PM - 08:00PM',
        11 => 'Time: 08:00PM - 09:00PM',
        12 => 'Time: 09:00PM - 10:00PM',
        13 => 'Time: 10:00PM - 11:00PM',
        14 => 'Time: 11:00PM - 12:00AM',
    ],
];