<?php

/**
 * @package App\Rules
 *
 * @class CheckSlot
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instavertia Pvt. Ltd. All rights reserved.
 */

namespace App\Rules;

use App\Drug;
use App\Http\Requests\BookingRequest;
use Illuminate\Contracts\Validation\Rule;

class CheckSlot implements Rule
{

    /**
     * Create a new rule instance.
     *
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $slots = \Config::get('constants.SLOTS');
        if (!in_array($value, $slots)) {
            // here we will check if slot id is incorret
        }
        $bookings = \DB::table('bookigs')->where('created_at', '>=', Carbon::now()->toDateTimeString())->get();
        foreach($bookings as $booking) {
            if ($booking->slot_id == $value) {
                return false;
            }
        }
        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return \Lang::get('messages.slot_not_available');
    }
}