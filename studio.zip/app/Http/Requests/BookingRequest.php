<?php

/**
 * CardRequest
 *
 * @package App\Http\Requests
 *
 * @class BookingRequest
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instavertias Pvt. Ltd. All rights reserved.
 */

namespace App\Http\Requests;

use App\Rules\CheckSlot;
use Illuminate\Foundation\Http\FormRequest;

class BookingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'studio_id' => 'required|exists:studios,id',
            'booking_date' => 'nullable|after:yesterday',
            'slot_id' => ['required', new CheckSlot($request->slot_id)],
            'is_active' => 'required|in:0,1',
        ];
    }

    /**
     * custom messages
     * @return array
     */
    public function messages()
    {
        return [
            'name.regex' => 'Entered invalid studio name.'
            // we can add more custom messages similarly. 
        ];
    }
}
