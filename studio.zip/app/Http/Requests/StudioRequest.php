<?php

namespace App\Http\Requests;

use Illuminate\Support\Facades\Config;
use Illuminate\Foundation\Http\FormRequest;

class StudioRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $studioId = isset($this->studio->id) ? $this->studio->id : null;
        return [
            'name' => 'required|max:100|regex:/^[a-zA-Z\s]*$/',
            'email' => 'required|max:50|regex:/^([a-z0-9+_\.-]+)@([\da-z+\.-]+)\.([a-z+\.]{2,6})$/|unique:studios,email,' . $studioId,
            'address' => 'required|max:200',
            'open' => 'date|date_format:H:i A',
            'close' => 'date|after:open|date_format:H:i A',
            'is_active' => 'required|in:0,1',
        ];
    }

    /**
     * custom messages
     * @return array
     */
    public function messages()
    {
        return [
            'name.regex' => 'Entered invalid studio name.'
            // we can add more custom messages similarly. 
        ];
    }
}
