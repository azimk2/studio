<?php

/**
 * @package App
 *
 * @class BookingController
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instaveritas Pvt. Ltd. All rights reserved.
 */

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Http\Requests\BookingRequest;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $limit = isset($request->limit) ? $request->limit : 10;
        $offset = isset($request->offset) ? $request->offset : 0;
        $booking = new Booking();
        if ($request->search) {
            $advices = $booking->where('name', 'LIKE', "%{$request->search}%");
        }
        $bookings = $booking->orderby('id', 'DESC')->offset($offset)->limit($limit)->get();
        return view('studio.index', compact('bookings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('studio.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param BookingRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(BookingRequest $request)
    {
        $booking = Booking::create([
            'user_id' => auth()->user()->id,
            'booking_date' => date('Y-m-d', strtotime($request->booking_date)),
            'studio_id' => $request->studio_id,
            'slot_id' => $request->slot_id,
        ]);
        return redirect()->route('bookings.index')->with('success', \Lang::get('messages.studio_create_successfully'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show(Booking $booking)
    {
        return view('bookings.show', compact('booking'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Booking $booking)
    {
        return view('bookings.edit', compact('booking'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(BookingRequest $request, Booking $booking)
    {
        // here we will update the booking
        // it depends either we want to allow user to update booking or not
        $booking->update([
            'user_id' => auth()->user()->id,
            'booking_date' => date('Y-m-d', strtotime($request->booking_date)),
            'studio_id' => $request->studio_id,
            'slot_id' => $request->slot_id,
        ]);
        return redirect()->route('bookings.index')->with('success', \Lang::get('messages.booking_updated_successfully'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Booking $booking)
    {
        // it depends either we want to allow user to delete booking or not
        $booking->delete();
        return redirect()->route('bookings.index')->with('success', \Lang::get('messages.booking_deleted_successfully'));
    }
}
