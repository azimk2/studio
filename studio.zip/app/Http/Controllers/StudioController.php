<?php

/**
 * @package App
 *
 * @class StudioController
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instaveritas Pvt. Ltd. All rights reserved.
 */

namespace App\Http\Controllers;

use App\Http\Requests\StudioRequest;
use App\Models\Studio;

class StudioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $bookings = Studio::whereIsActive(1)->get();
        return view('studio.index', compact('bookings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('studio.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StudioRequest $request
     * @return \Illuminate\Http\Response
     */
    public function store(StudioRequest $request)
    {
        try {
            Studio::create($request->validated());
            return redirect()->route('studios.index')->with('success', \Lang::get('messages.studio_create_successfully'));
        } catch (\Exception $error) {
            return redirect()->back()->withInput()->with('error', \Lang::get('messages.internal_server_error'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Studio  $studio
     * @return \Illuminate\Http\Response
     */
    public function show(Studio $studio)
    {
        return view('studio.show', compact('studio'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Studio  $studio
     * @return \Illuminate\Http\Response
     */
    public function edit(Studio $studio)
    {
        return view('studio.edit', compact('studio'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param StudioRequest $request
     * @param  \App\Models\Studio $studio
     * @return \Illuminate\Http\Response
     */
    public function update(StudioRequest $request, Studio $studio)
    {
        // here we will update the studio
        $studio->update($request->validated());
        return redirect()->route('studios.index')->with('success', \Lang::get('messages.studio_updated_successfully'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Studio  $studio
     * @return \Illuminate\Http\Response
     */
    public function destroy(Studio $studio)
    {
        $studio->delete();
        return redirect()->route('studios.index')->with('success', \Lang::get('messages.studio_deleted_successfully'));
    }
}
