<?php

/**
 * Booking
 *
 * @package App\Http\Requests
 *
 * @class Booking
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instavertia Pvt. Ltd. All rights reserved.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id', 'studio_id', 'slot_id'
    ];
}
