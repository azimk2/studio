<?php

/**
 * Studio
 *
 * @package App\Http\Requests
 *
 * @class Studio
 *
 * @author Azim Khan <azimk2@live.com>
 *
 * @copyright 2021 Instavertia Pvt. Ltd. All rights reserved.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Studio extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'address', 'open', 'close', 'is_active'
    ];
}
